package modelo.pedido;

import modelo.persistencia.PersistenciaUtil;
import modelo.carrito.ItemCarrito;
import modelo.usuarios.Cliente;
import java.util.ArrayList;
import java.util.List;

public class PedidoServicio {

    private List<Pedido> pedidos;
    private static final String ARCHIVO_PEDIDOS = "data/pedidos.dat";

    public PedidoServicio() {
        this.pedidos = PersistenciaUtil.cargarLista(ARCHIVO_PEDIDOS);
    }

    public void guardarCambios() {
        PersistenciaUtil.guardarLista(ARCHIVO_PEDIDOS, pedidos);
    }

    public Pedido realizarPedido(Cliente cliente, List<ItemCarrito> items, double total) {
        long nuevoId = generarNuevoId();
        Pedido pedido = new Pedido(nuevoId, cliente, items, total);
        pedidos.add(pedido);
        guardarCambios();
        return pedido;
    }

    public List<Pedido> getPedidosDeCliente(Cliente cliente) {
        List<Pedido> misPedidos = new ArrayList<>();
        for (Pedido p : pedidos) {
            if (p.getCliente().getEmail().equals(cliente.getEmail())) {
                misPedidos.add(p);
            }
        }
        return misPedidos;
    }

    private long generarNuevoId() {
        long max = 0;
        for (Pedido p : pedidos) {
            if (p.getId() > max) max = p.getId();
        }
        return max + 1;
    }
}
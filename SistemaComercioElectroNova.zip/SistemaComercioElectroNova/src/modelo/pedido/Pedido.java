package modelo.pedido;

import modelo.usuarios.Cliente;
import modelo.carrito.ItemCarrito;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class Pedido implements java.io.Serializable {

    private long id;
    private Cliente cliente;
    private List<ItemCarrito> items;
    private double total;
    private String estado;
    private LocalDateTime fechaPedido;

    public Pedido(long id, Cliente cliente, List<ItemCarrito> items, double total) {
        this.id = id;
        this.cliente = cliente;
        this.items = new ArrayList<>(items);
        this.total = total;
        this.estado = "CONFIRMADO";
        this.fechaPedido = LocalDateTime.now();
    }

    public Pedido(Cliente cliente, List<ItemCarrito> items, double v) {
    }

    public long getId() {
        return id;
    }
    public Cliente getCliente() {
        return cliente;
    }
    public List<ItemCarrito> getItems() {
        return items;
    }
    public double getTotal() {
        return total;
    }
    public String getEstado() {
        return estado;
    }
    public LocalDateTime getFechaPedido() {
        return fechaPedido;
    }

    @Override
    public String toString() {
        return "Pedido #" +
                id + " | " +
                fechaPedido.toLocalDate() +
                " | Total: $" + total +
                " | Estado: " + estado;
    }
}
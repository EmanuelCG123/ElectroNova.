package modelo.persistencia;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class PersistenciaUtil {

    public static void guardarLista(String nombreArchivo, List<?> lista) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(nombreArchivo))) {
            oos.writeObject(lista);
            System.out.println("Datos guardados correctamente en: " + nombreArchivo);
        } catch (IOException e) {
            System.out.println("Error al guardar archivo " + nombreArchivo + ": " + e.getMessage());
        }
    }

    public static <T> List<T> cargarLista(String nombreArchivo) {
        File archivo = new File(nombreArchivo);

        if (!archivo.exists()) {
            return new ArrayList<>();
        }

        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(archivo))) {
            Object objetoLeido = ois.readObject();

            if (objetoLeido instanceof List) {
                return (List<T>) objetoLeido;
            } else {
                System.out.println("El archivo no contiene una lista válida.");
                return new ArrayList<>();
            }

        } catch (IOException | ClassNotFoundException e) {
            System.out.println("Error al cargar " + nombreArchivo + ": " + e.getMessage());
            return new ArrayList<>();
        }
    }
}
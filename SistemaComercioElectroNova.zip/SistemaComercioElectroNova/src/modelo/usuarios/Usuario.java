package modelo.usuarios;

import java.time.LocalDateTime;

public abstract class Usuario implements java.io.Serializable {

    private long id;
    private String nombre;
    private String apellido;
    private String email;
    private String password;
    private String telefono;
    private LocalDateTime fechaRegistro;
    private boolean activo;

    public Usuario() {
        this.fechaRegistro = LocalDateTime.now();
        this.activo = true;
    }

    public Usuario(String nombre, String apellido, String email, String password) {
        this();
        this.nombre = nombre;
        this.apellido = apellido;
        this.email = email;
        this.password = password;
    }

    public abstract String getTipoUsuario();

    public boolean iniciarSesion(String email, String password) {
        return this.email != null && this.email.equalsIgnoreCase(email) &&
                this.password != null && this.password.equals(password);
    }

    public long getId() {
        return id;
    }
    public void setId(long id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }
    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getEmail() {
        return email;
    }
    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }
    public void setPassword(String password) {
        this.password = password;
    }

    public String getTelefono() {
        return telefono;
    }
    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public LocalDateTime getFechaRegistro() {
        return fechaRegistro;
    }

    public boolean isActivo() { return activo; }
    public void setActivo(boolean activo) { this.activo = activo; }

    @Override
    public String toString() {
        return "Usuario{ " +
                "id: " + id +
                ", nombre:" + nombre + "\"" +
                ", email: " + email + "\"" +
                ", tipo/" + getTipoUsuario() +
                " }";
    }
}
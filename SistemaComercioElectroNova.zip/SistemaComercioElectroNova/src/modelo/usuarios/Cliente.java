package modelo.usuarios;

import java.util.ArrayList;
import java.util.List;

public class Cliente extends Usuario implements java.io.Serializable{

    private String direccion;
    private String ciudad;
    private List<Long> pedidos;

    public Cliente() {
        super();
        this.pedidos = new ArrayList<>();
    }

    public Cliente(String nombre, String apellido, String email, String password,
                   String direccion, String ciudad) {
        super(nombre, apellido, email, password);
        this.direccion = direccion;
        this.ciudad = ciudad;
        this.pedidos = new ArrayList<>();
    }

    @Override
    public String getTipoUsuario() {
        return "CLIENTE";
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getCiudad() {
        return ciudad;
    }

    public void setCiudad(String ciudad) {
        this.ciudad = ciudad;
    }

    public List<Long> getPedidos() {
        return new ArrayList<>(pedidos);
    }

    public void agregarPedido(Long pedidoId) {
        this.pedidos.add(pedidoId);
    }
}
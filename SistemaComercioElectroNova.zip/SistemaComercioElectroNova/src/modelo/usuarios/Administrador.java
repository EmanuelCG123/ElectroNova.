package modelo.usuarios;

public class Administrador extends Usuario implements java.io.Serializable{

    private String nivelAcceso;

    public Administrador() {
        super();
        this.nivelAcceso = "admin";
    }

    public Administrador(String nombre, String apellido, String email, String password) {
        super(nombre, apellido, email, password);
        this.nivelAcceso = "dueño";
    }

    @Override
    public String getTipoUsuario() {
        return "ADMINISTRADOR";
    }

    public boolean esDueno() {
        return "dueño".equals(nivelAcceso);
    }

    public boolean puedeGestionarProductos() {
        return true;
    }

    public boolean puedeGestionarUsuarios() {
        return esDueno();
    }

    public String getNivelAcceso() {
        return nivelAcceso;
    }

    public void setNivelAcceso(String nivelAcceso) {
        this.nivelAcceso = nivelAcceso;
    }

    @Override
    public String toString() {
        return "Administrador{" +
                "id=" + getId() +
                ", nombre='" + getNombre() + '\'' +
                ", email='" + getEmail() + '\'' +
                ", nivelAcceso='" + nivelAcceso + '\'' +
                '}';
    }
}
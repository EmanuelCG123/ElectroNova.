package modelo.gestion;

import java.time.LocalDateTime;

public abstract class Producto implements java.io.Serializable{

    private long id;
    private String nombre;
    private String descripcion;
    private double precio;
    private int stock;
    private String categoria;
    private LocalDateTime fechaCreacion;

    public Producto() {
        this.fechaCreacion = LocalDateTime.now();
    }

    public Producto(String nombre, String descripcion, double precio, int stock, String categoria) {
        this();
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.precio = precio;
        this.stock = stock;
        this.categoria = categoria;
    }

    public abstract String getTipoProducto();

    public boolean reducirStock(int cantidad) {
        if (cantidad <= 0 || stock < cantidad) {
            return false;
        }
        stock -= cantidad;
        return true;
    }

    public long getId() {
        return id;
    }
    public void setId(long id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDescripcion() {
        return descripcion;
    }
    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public double getPrecio() {
        return precio;
    }
    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public int getStock() {
        return stock;
    }
    public void setStock(int stock) {
        this.stock = stock;
    }

    public String getCategoria() {
        return categoria;
    }
    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    public LocalDateTime getFechaCreacion() {
        return fechaCreacion;
    }

    @Override
    public String toString() {
        return "Producto{" +
                "id=" + id +
                ", nombre='" + nombre + '\'' +
                ", precio=" + precio +
                ", stock=" + stock +
                ", tipo=" + getTipoProducto() +
                '}';
    }
}
package modelo.gestion;

public class addProducto extends Producto implements java.io.Serializable {

    private String marca;
    private String modelo;
    private int garantiaMeses;

    public addProducto(String nombre, String descripcion, double precio, int stock,
                       String categoria, String marca, String modelo, int garantiaMeses) {
        super(nombre, descripcion, precio, stock, categoria);
        this.marca = marca;
        this.modelo = modelo;
        this.garantiaMeses = garantiaMeses;
    }

    @Override
    public String getTipoProducto() {
        return "ELECTRONICO";
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public int getGarantiaMeses() {
        return garantiaMeses;
    }

    public void setGarantiaMeses(int garantiaMeses) {
        this.garantiaMeses = garantiaMeses;
    }
}
package modelo.gestion;

import modelo.persistencia.PersistenciaUtil;
import java.util.ArrayList;
import java.util.List;

public class gestionProducto {

    private List<Producto> productos;
    private static final String ARCHIVO_PRODUCTOS = "data/productos.dat";

    public gestionProducto() {
        this.productos = PersistenciaUtil.cargarLista(ARCHIVO_PRODUCTOS);
    }

    public void guardarCambios() {
        PersistenciaUtil.guardarLista(ARCHIVO_PRODUCTOS, productos);
    }

    public void agregarProducto(Producto p) {
        if (p.getId() == 0) {
            p.setId(generarNuevoId());
        }
        productos.add(p);
        guardarCambios();
    }

    public List<Producto> getTodosProductos() {
        return new ArrayList<>(productos);
    }

    public Producto buscarPorId(long id) {
        for (Producto p : productos) {
            if (p.getId() == id) return p;
        }
        return null;
    }

    public boolean actualizarProducto(long id, String nombre, String descripcion, double precio, int stock) {
        Producto p = buscarPorId(id);
        if (p != null) {
            p.setNombre(nombre);
            p.setDescripcion(descripcion);
            p.setPrecio(precio);
            p.setStock(stock);
            guardarCambios();
            return true;
        }
        return false;
    }

    public boolean eliminarProducto(long id) {
        boolean eliminado = productos.removeIf(p -> p.getId() == id);
        if (eliminado) guardarCambios();
        return eliminado;
    }

    public boolean reducirStock(long id, int cantidad) {
        Producto p = buscarPorId(id);
        if (p != null && p.reducirStock(cantidad)) {
            guardarCambios();
            return true;
        }
        return false;
    }

    private long generarNuevoId() {
        long max = 0;
        for (Producto p : productos) {
            if (p.getId() > max) max = p.getId();
        }
        return max + 1;
    }

}
package principal;

import modelo.usuarios.*;
import modelo.gestion.*;
import modelo.carrito.*;
import modelo.pedido.*;
import java.util.List;
import java.util.Scanner;

public class Main {

    private static Scanner scanner = new Scanner(System.in);
    private static gestionProducto gestionProducto = new gestionProducto();
    private static Carrito carrito = new Carrito();
    private static Usuario usuarioActual = null;

    public static void main(String[] args) {
        System.out.println("=== BIENVENIDO A ELECTRONOVA ===");

        boolean salir = false;

        while (!salir) {
            if (usuarioActual == null) {
                mostrarMenuPrincipal();
            } else if (usuarioActual instanceof Administrador) {
                mostrarMenuAdministrador();
            } else if (usuarioActual instanceof Cliente) {
                mostrarMenuCliente();
            }
        }
    }

    private static void mostrarMenuPrincipal() {
        System.out.println("\n=== MENÚ PRINCIPAL ===");
        System.out.println("1. Iniciar Sesión");
        System.out.println("2. Registrarse como Cliente");
        System.out.println("3. Ver Productos");
        System.out.println("0. Salir");
        System.out.print("Seleccione una opción: ");

        int opcion = scanner.nextInt();
        scanner.nextLine();

        switch (opcion) {
            case 1:
                iniciarSesion();
                break;
            case 2:
                registrarCliente();
                break;
            case 3:
                verProductos();
                break;
            case 0:
                System.out.println("¡Gracias por visitar ElectroNova!");
                System.exit(0);
                break;
            default:
                System.out.println("Opción inválida.");
        }
    }

    private static void iniciarSesion() {
        System.out.print("Email: ");
        String email = scanner.nextLine();
        System.out.print("Contraseña: ");
        String password = scanner.nextLine();

        // usuarios de prueba
        if (email.equalsIgnoreCase("admin@electronova.com") && password.equals("admin123")) {
            usuarioActual = new Administrador("Admin", "Principal", email, password);
            System.out.println("¡Bienvenido Administrador!");
        } else if (email.equalsIgnoreCase("cliente@electronova.com") && password.equals("cliente123")) {
            usuarioActual = new Cliente("Luis", "García", email, password, "Calle 123", "Cartagena");
            System.out.println("¡Bienvenido Cliente!");
        } else {
            System.out.println("Credenciales incorrectas.");
        }
    }

    private static void registrarCliente() {
        System.out.println("\n=== REGISTRO DE CLIENTE ===");

        System.out.print("Nombre: ");
        String nombre = scanner.nextLine();
        System.out.print("Apellido: ");
        String apellido = scanner.nextLine();
        System.out.print("Email: ");
        String email = scanner.nextLine();
        System.out.print("Contraseña: ");
        String password = scanner.nextLine();
        System.out.print("Dirección: ");
        String direccion = scanner.nextLine();
        System.out.print("Ciudad: ");
        String ciudad = scanner.nextLine();

        Cliente nuevoCliente = new Cliente(nombre, apellido, email, password, direccion, ciudad);
        System.out.println("\n¡Registro exitoso! Bienvenido " + nombre);
        usuarioActual = nuevoCliente;
    }

    private static void verProductos() {
        List<Producto> productos = gestionProducto.getTodosProductos();

        if (productos.isEmpty()) {
            System.out.println("No hay productos disponibles aún.");
            return;
        }

        System.out.println("\n=== PRODUCTOS DISPONIBLES ===");
        for (Producto p : productos) {
            System.out.println(p);
        }
    }

    private static void mostrarMenuAdministrador() {
        System.out.println("\n=== MENÚ ADMINISTRADOR ===");
        System.out.println("1. Agregar Producto");
        System.out.println("2. Ver Productos");
        System.out.println("3. Gestionar Stock");
        System.out.println("4. Cerrar Sesión");
        System.out.print("Opción: ");

        int opcion = scanner.nextInt();
        scanner.nextLine();

        switch (opcion) {
            case 1:
                agregarProducto();
                break;
            case 2:
                verProductos();
                break;
            case 3:
                gestionarStock();
                break;
            case 4:
                usuarioActual = null;
                System.out.println("Sesión cerrada.");
                break;
            default:
                System.out.println("Opción inválida.");
        }
    }

    private static void agregarProducto() {
        System.out.println("\n=== AGREGAR NUEVO PRODUCTO ===");
        System.out.print("Nombre: ");
        String nombre = scanner.nextLine();
        System.out.print("Descripción: ");
        String desc = scanner.nextLine();
        System.out.print("Precio: ");
        double precio = scanner.nextDouble();
        System.out.print("Stock: ");
        int stock = scanner.nextInt();
        scanner.nextLine();
        System.out.print("Categoría: ");
        String categoria = scanner.nextLine();

        addProducto nuevo = new addProducto(nombre, desc, precio, stock, categoria, "Genérica", "Modelo", 12);
        gestionProducto.agregarProducto(nuevo);
        System.out.println("¡Producto agregado exitosamente!");
    }

    private static void gestionarStock() {
        verProductos();

        System.out.print("Ingrese ID del producto: ");
        long id = scanner.nextLong();
        scanner.nextLine();

        System.out.print("Nuevo Nombre: ");
        String nuevoNombre = scanner.nextLine();

        System.out.print("Nueva Descripción: ");
        String nuevaDescripcion = scanner.nextLine();

        System.out.print("Nuevo Precio: ");
        double nuevoPrecio = scanner.nextDouble();

        System.out.print("Nuevo Stock: ");
        int nuevoStock = scanner.nextInt();
        scanner.nextLine();

        if (gestionProducto.actualizarProducto(id, nuevoNombre, nuevaDescripcion, nuevoPrecio, nuevoStock)) {
            System.out.println("Producto actualizado correctamente.");
        } else {
            System.out.println("Producto no encontrado.");
        }
    }

    private static void mostrarMenuCliente() {
        System.out.println("\n=== MENÚ CLIENTE ===");
        System.out.println("1. Ver Productos");
        System.out.println("2. Agregar al Carrito");
        System.out.println("3. Ver Carrito");
        System.out.println("4. Realizar Pedido");
        System.out.println("5. Mi Perfil");
        System.out.println("6. Cerrar Sesión");
        System.out.print("Opción: ");

        int opcion = scanner.nextInt();
        scanner.nextLine();

        switch (opcion) {
            case 1:
                verProductos();
                break;
            case 2:
                agregarAlCarrito();
                break;
            case 3:
                verCarrito();
                break;
            case 4:
                realizarPedido();
                break;
            case 5:
                verPerfil();
                break;
            case 6:
                usuarioActual = null;
                carrito.vaciarCarrito();
                System.out.println("Sesión cerrada.");
                break;
            default:
                System.out.println("Opción inválida.");
        }
    }

    private static void agregarAlCarrito() {
        verProductos();
        System.out.print("Ingrese ID del producto: ");
        long id = scanner.nextLong();
        System.out.print("Cantidad: ");
        int cantidad = scanner.nextInt();
        scanner.nextLine();

        Producto p = gestionProducto.buscarPorId(id);
        if (p != null) {
            if (p.getStock() >= cantidad) {
                carrito.agregarProducto(p, cantidad);
                System.out.println("Producto agregado al carrito correctamente.");
            } else {
                System.out.println("Stock insuficiente.");
            }
        } else {
            System.out.println("Producto no encontrado.");
        }
    }

    private static void verCarrito() {
        if (carrito.estaVacio()) {
            System.out.println("El carrito está vacío.");
            return;
        }

        System.out.println("\n=== TU CARRITO ===");
        for (ItemCarrito item : carrito.getItems()) {
            System.out.println(item);
        }
        System.out.println("Total a pagar: $" + carrito.calcularTotal());
    }

    private static void realizarPedido() {
        if (carrito.estaVacio()) {
            System.out.println("El carrito está vacío. Agrega productos primero.");
            return;
        }

        verCarrito();
        System.out.print("\n¿Confirmar el pedido? (S/N): ");
        String confirm = scanner.nextLine().trim();

        if (confirm.equalsIgnoreCase("S")) {
            Cliente cliente = (Cliente) usuarioActual;
            Pedido nuevoPedido = new Pedido(cliente, carrito.getItems(), carrito.calcularTotal());

            // Reducir stock de los productos
            for (ItemCarrito item : carrito.getItems()) {
                gestionProducto.reducirStock(item.getProducto().getId(), item.getCantidad());
            }

            System.out.println("\n¡Pedido realizado con éxito!");
            System.out.println(nuevoPedido);
            carrito.vaciarCarrito();
        } else {
            System.out.println("Pedido cancelado.");
        }
    }

    private static void verPerfil() {
        System.out.println("\n=== MI PERFIL ===");
        System.out.println(usuarioActual);
    }
}